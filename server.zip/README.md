# Server Repo for the Mobile BTC Wallet

## 1 | Description

Current ver: v0.01

MongoDB, Express, Node.js

## 2 | Installing

```
npm install
```

## 3 | Running

> node server.js

deprecated - npm run dev


## 4 | Testing

Signup 

```
curl -X POST -H "Content-Type: application/json" -d "{"username": "uniqueuser", "password": "password123", "email": "uniqueuser@example.com", "firstName": "Unique", "lastName": "User", "phone": "1234567890", "accessCode": "1234"}" http://localhost:4000/users/signup
```

Login 

```
curl -X POST -H "Content-Type: application/json" -d "{"email": "uniqueuser@example.com", "password": "password123"}" http://localhost:4000/users/login
```

Create Child Profile

```
curl -X POST http://localhost:4000/children -H "Content-Type: application/json" -d '{ "userId": "609c24df31c2f90015e073d2", "firstName": "Jane", "lastName": "Doe", "diabetesType": "Type 1", "insulinRegimen": "Long-acting", "allergies": "None", "age": 10, "diagnosedAge": 9, "comorbidConditions": "None", "cgmType": "Dexcom" }
```

Connect CGM
```
curl -X POST http://localhost:4000/children/connect-cgm \
  -H "Content-Type: application/json" \
  -d '{
    "childId": "your-child-id",
    "data": [
      { "sgv": 100, "dateString": "2023-01-01T00:00:00Z" },
      { "sgv": 110, "dateString": "2023-01-01T01:00:00Z" },
      { "sgv": 120, "dateString": "2023-01-01T02:00:00Z" }
    ]
  }'
```

Connect CGM
```
  curl -X POST http://localhost:4000/children/connect-cgm \
  -H "Content-Type: application/json" \
  -d '{
    "childId": "your-child-id",
    "nightscoutUrl": "your-nightscout-url",
    "apiSecret": "your-api-secret"
  }'
```

Conncet CGM
```
    curl -X POST http://localhost:4000/children/connect-cgm \
  -H "Content-Type: application/json" \
  -d '{
    "childId": "6646f5c80b381dd96a2b7a0b",
    "nightscoutUrl": "http://localhost:1337",
    "apiSecret": "$2a$12$vt8KlyasT3k4OfwyPl8MF.vL0gNvdFGOYg.oJLEs9VUgEcxC6Ejmy"
  }'
```

Subscribe (Listen?)
```
  curl -X POST http://localhost:4000/subscribe \
  -H "Content-Type: application/json" \
  -d '{
    "childId": "your-child-id"
  }'
```

Subscribe (Listen?)
```
  curl -X POST http://localhost:4000/subscribe \
  -H "Content-Type: application/json" \
  -d '{
    "childId": "6646f5c80b381dd96a2b7a0b"
  }'
```