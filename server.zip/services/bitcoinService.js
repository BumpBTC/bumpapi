const bitcoin = require('bitcoinjs-lib');
const axios = require('axios');
const Client = require('bitcoin-core');

const client = new Client({
  network: 'testnet',
  host: process.env.BITCOIN_RPC_HOST,
  port: process.env.BITCOIN_RPC_PORT,
  username: process.env.BITCOIN_RPC_USER,
  password: process.env.BITCOIN_RPC_PASS,
});

exports.generateBitcoinAddress = async () => {
  const keyPair = bitcoin.ECPair.makeRandom();
  const { address } = bitcoin.payments.p2pkh({ pubkey: keyPair.publicKey });
  return { address, privateKey: keyPair.toWIF() };
};

exports.splitPrivateKey = (privateKey) => {
  // Implement key splitting logic here
  // For simplicity, we're just returning the same key
  // In a real implementation, you'd use a secure key splitting algorithm
  return { serverKeyShare: privateKey, clientKeyShare: privateKey };
};

exports.getBalance = async (address) => {
  const response = await axios.get(`https://api.blockcypher.com/v1/btc/test3/addrs/${address}/balance`);
  return response.data.balance / 1e8; // Convert satoshis to BTC
};

exports.sendTransaction = async (fromAddress, toAddress, amount, serverKeyShare, clientKeyShare) => {
  // In a real implementation, you'd reconstruct the full private key here
  const privateKey = serverKeyShare; // This is a simplification

  const utxos = await client.listUnspent(0, 9999999, [fromAddress]);
  const transaction = new bitcoin.TransactionBuilder(bitcoin.networks.testnet);

  let totalAmount = 0;
  for (const utxo of utxos) {
    transaction.addInput(utxo.txid, utxo.vout);
    totalAmount += utxo.amount * 1e8;
    if (totalAmount >= amount * 1e8) break;
  }

  transaction.addOutput(toAddress, amount * 1e8);
  if (totalAmount > amount * 1e8) {
    transaction.addOutput(fromAddress, totalAmount - amount * 1e8 - 1000); // Change output, 1000 satoshis for fee
  }

  const keyPair = bitcoin.ECPair.fromWIF(privateKey, bitcoin.networks.testnet);
  for (let i = 0; i < transaction.inputs.length; i++) {
    transaction.sign(i, keyPair);
  }

  const txHex = transaction.build().toHex();
  const txid = await client.sendRawTransaction(txHex);
  return txid;
};