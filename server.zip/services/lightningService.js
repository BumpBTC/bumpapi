const lnService = require('ln-service');

let lnd;

exports.initLightning = async () => {
  const { lnd: lightningDaemon } = await lnService.authenticatedLndGrpc({
    cert: process.env.LND_CERT,
    macaroon: process.env.LND_MACAROON,
    socket: process.env.LND_SOCKET,
  });
  lnd = lightningDaemon;
};

exports.createInvoice = async (amount) => {
  const invoice = await lnService.createInvoice({ lnd, tokens: amount * 1e8 });
  return invoice;
};

exports.payInvoice = async (paymentRequest) => {
  const payment = await lnService.pay({ lnd, request: paymentRequest });
  return payment;
};

exports.getChannelBalance = async () => {
  const { channel_balance } = await lnService.getChannelBalance({ lnd });
  return channel_balance;
};