const express = require('express');
const { getBalance, sendBitcoin } = require('../controllers/walletController');
const { authMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(authMiddleware);

router.get('/balance', getBalance);
router.post('/send', sendBitcoin);

module.exports = router;