const express = require('express');
const { createLightningInvoice, payLightningInvoice, getLightningBalance } = require('../controllers/lightningController');
const { authMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(authMiddleware);

router.post('/invoice', createLightningInvoice);
router.post('/pay', payLightningInvoice);
router.get('/balance', getLightningBalance);

module.exports = router;