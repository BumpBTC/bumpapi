const User = require('../models/User');
const { lockFunds, unlockFunds } = require('../services/bitcoinService');

exports.stakeTokens = async (req, res) => {
  try {
    const { amount } = req.body;
    const user = await User.findById(req.userId);
    
    await lockFunds(user.btcAddress, amount);
    
    user.stakedAmount = amount;
    user.stakingStartDate = new Date();
    await user.save();
    
    res.json({ message: 'Tokens staked successfully', stakedAmount: amount });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.unstakeTokens = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    
    if (!user.stakedAmount) {
      throw new Error('No staked tokens found');
    }
    
    const currentDate = new Date();
    const stakingPeriod = (currentDate - user.stakingStartDate) / (1000 * 60 * 60 * 24); // in days
    
    if (stakingPeriod < 30) {
      throw new Error('Minimum staking period of 30 days not met');
    }
    
    const reward = calculateReward(user.stakedAmount, stakingPeriod);
    await unlockFunds(user.btcAddress, user.stakedAmount + reward);
    
    user.stakedAmount = 0;
    user.stakingStartDate = null;
    await user.save();
    
    res.json({ message: 'Tokens unstaked successfully', unstakedAmount: user.stakedAmount, reward });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

function calculateReward(amount, days) {
  // Simple reward calculation: 5% APY
  return amount * (0.05 / 365) * days;
}

// src/services/bitcoinService.js
const bitcoin = require('bitcoinjs-lib');
const axios = require('axios');
const Client = require('bitcoin-core');

const client = new Client({ 
  network: 'testnet', 
  username: process.env.BITCOIN_RPC_USER, 
  password: process.env.BITCOIN_RPC_PASS, 
  host: process.env.BITCOIN_RPC_HOST, 
  port: process.env.BITCOIN_RPC_PORT 
});

exports.generateBitcoinAddress = async () => {
  const keyPair = bitcoin.ECPair.makeRandom();
  const { address } = bitcoin.payments.p2pkh({ pubkey: keyPair.publicKey });
  return { address, privateKey: keyPair.toWIF() };
};

exports.splitPrivateKey = (privateKey) => {
  // For demo purposes, we're not actually splitting the key
  // In a real implementation, you'd use a secure key splitting algorithm
  return { serverKeyShare: privateKey, clientKeyShare: privateKey };
};

exports.getBalance = async (address) => {
  const response = await axios.get(`https://api.blockcypher.com/v1/btc/test3/addrs/${address}/balance`);
  return response.data.balance / 1e8; // Convert satoshis to BTC
};

exports.sendTransaction = async (fromAddress, toAddress, amount, serverKeyShare, clientKeyShare) => {
  // In a real implementation, you'd reconstruct the full private key here
  const privateKey = serverKeyShare; // This is a simplification

  const utxos = await client.listUnspent(0, 9999999, [fromAddress]);
  const transaction = new bitcoin.TransactionBuilder(bitcoin.networks.testnet);

  let totalAmount = 0;
  for (const utxo of utxos) {
    transaction.addInput(utxo.txid, utxo.vout);
    totalAmount += utxo.amount * 1e8;
    if (totalAmount >= amount * 1e8) break;
  }

  transaction.addOutput(toAddress, amount * 1e8);
  if (totalAmount > amount * 1e8) {
    transaction.addOutput(fromAddress, totalAmount - amount * 1e8 - 1000); // Change output, 1000 satoshis for fee
  }

  const keyPair = bitcoin.ECPair.fromWIF(privateKey, bitcoin.networks.testnet);
  for (let i = 0; i < transaction.inputs.length; i++) {
    transaction.sign(i, keyPair);
  }

  const txHex = transaction.build().toHex();
  const txid = await client.sendRawTransaction(txHex);
  return txid;
};

exports.lockFunds = async (address, amount) => {
  // In a real implementation, you'd move funds to a special staking address
  console.log(`Locking ${amount} BTC from ${address} for staking`);
};

exports.unlockFunds = async (address, amount) => {
  // In a real implementation, you'd move funds back from the staking address
  console.log(`Unlocking ${amount} BTC to ${address} after staking`);
};

// src/services/lightningService.js
const lnService = require('ln-service');

let lnd;

exports.initLightning = async () => {
  const { lnd: lightningDaemon } = await lnService.authenticatedLndGrpc({
    cert: process.env.LND_CERT,
    macaroon: process.env.LND_MACAROON,
    socket: process.env.LND_SOCKET,
  });
  lnd = lightningDaemon;
};

exports.createLightningNode = async () => {
  // In a real implementation, you'd create a new lightning node for each user
  // For demo purposes, we'll just return a dummy pubkey
  return 'dummy_pubkey_' + Math.random().toString(36).substring(7);
};

exports.createInvoice = async (nodePubkey, amount) => {
  const invoice = await lnService.createInvoice({ lnd, tokens: amount * 1e8 });
  return invoice;
};

exports.payInvoice = async (nodePubkey, paymentRequest) => {
  const payment = await lnService.pay({ lnd, request: paymentRequest });
  return payment;
};

exports.getChannelBalance = async (nodePubkey) => {
  const { channel_balance } = await lnService.getChannelBalance({ lnd });
  return channel_balance;
};