const User = require('../models/User');
const { getBalance, sendTransaction } = require('../services/bitcoinService');

exports.getBalance = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    const balance = await getBalance(user.btcAddress);
    res.json({ balance });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.sendBitcoin = async (req, res) => {
  try {
    const { toAddress, amount, clientKeyShare } = req.body;
    const user = await User.findById(req.userId);
    
    const txid = await sendTransaction(user.btcAddress, toAddress, amount, user.serverKeyShare, clientKeyShare);
    res.json({ txid });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};