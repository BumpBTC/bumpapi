const { createInvoice, payInvoice, getChannelBalance } = require('../services/lightningService');
const User = require('../models/User');

exports.createLightningInvoice = async (req, res) => {
  try {
    const { amount } = req.body;
    const user = await User.findById(req.userId);
    const invoice = await createInvoice(user.lightningNodePubkey, amount);
    res.json(invoice);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.payLightningInvoice = async (req, res) => {
  try {
    const { paymentRequest } = req.body;
    const user = await User.findById(req.userId);
    const payment = await payInvoice(user.lightningNodePubkey, paymentRequest);
    res.json(payment);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.getLightningBalance = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    const balance = await getChannelBalance(user.lightningNodePubkey);
    res.json({ balance });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};