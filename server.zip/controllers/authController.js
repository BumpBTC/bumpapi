// src/controllers/authController.js
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { generateBitcoinAddress, splitPrivateKey } = require('../services/bitcoinService');
const { createLightningNode } = require('../services/lightningService');

exports.register = async (req, res) => {
  try {
    const { email, password } = req.body;
    const { address, privateKey } = await generateBitcoinAddress();
    const { serverKeyShare, clientKeyShare } = splitPrivateKey(privateKey);
    const lightningNodePubkey = await createLightningNode();

    const user = new User({
      email,
      password,
      btcAddress: address,
      serverKeyShare,
      lightningNodePubkey,
    });

    await user.save();

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);

    res.status(201).json({ token, clientKeyShare, address, lightningNodePubkey });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      throw new Error('Invalid login credentials');
    }

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);

    res.json({ token, address: user.btcAddress, lightningNodePubkey: user.lightningNodePubkey });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};